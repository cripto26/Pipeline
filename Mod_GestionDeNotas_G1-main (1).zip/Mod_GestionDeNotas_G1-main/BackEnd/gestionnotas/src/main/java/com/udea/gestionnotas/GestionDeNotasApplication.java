package com.udea.gestionnotas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeNotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDeNotasApplication.class, args);
	}

}
