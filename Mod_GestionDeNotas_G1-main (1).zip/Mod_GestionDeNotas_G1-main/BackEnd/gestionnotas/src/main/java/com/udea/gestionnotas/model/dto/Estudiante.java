package com.udea.gestionnotas.model.dto;

import lombok.Data;

@Data
public class Estudiante  {

    private int estudianteId;
    private String nombre;
    private String correo;
    private String numeroIdentificacion;

}
