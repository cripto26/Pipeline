package com.udea.gestionnotas.service;

import com.udea.gestionnotas.model.dto.Profesor;

public interface IProfesorService {

  Profesor getProfesor(int profesorId);
}
