package com.udea.gestionnotas.service;

import com.udea.gestionnotas.model.dto.Estudiante;

public interface IEstudianteService {

    Estudiante getEstudiante(int estudianteId);
}
