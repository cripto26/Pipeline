package com.udea.gestionnotas.service;

import com.udea.gestionnotas.model.dto.Grupo;

public interface IGrupoService {

  Grupo getGrupo(int grupoId);
}
