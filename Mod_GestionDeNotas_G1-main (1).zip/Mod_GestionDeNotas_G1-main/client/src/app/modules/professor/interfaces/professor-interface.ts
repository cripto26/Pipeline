export interface IProfessor {
  profesorId: number;
  nombre: string;
  tipo: string;
  correoElectronico: string;
  usuarioPortal: string;
}