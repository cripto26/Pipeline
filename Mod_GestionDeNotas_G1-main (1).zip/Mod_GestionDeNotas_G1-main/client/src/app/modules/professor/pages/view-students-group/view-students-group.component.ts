import { Component } from '@angular/core';

@Component({
  selector: 'app-view-students-group',
  templateUrl: './view-students-group.component.html',
  styleUrls: ['./view-students-group.component.scss']
})
export class ViewStudentsGroupComponent {

  constructor() { }
}
